from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--automation-job", required=True)
args = parser.parse_args()

job_file = Path(args.automation_job)
job = json.loads(job_file.read_text(encoding="utf-8"))
params = job.get("params", {})

# Never print secrets. Demonstration only.
result = {
    "run_id": job["run_id"],
    "command_id": job["command_id"],
    "status": "success",
    "summary": "Example module received parameters correctly.",
    "data": {
        "site_url": params.get("site_url"),
        "profile_id": params.get("profile_id"),
        "api_key_received": bool(params.get("api_key")),
        "dry_run": params.get("dry_run"),
    },
    "finished_at": datetime.now(timezone.utc).isoformat(),
}

result_file = Path(os.environ["AUTOMATION_RESULT_FILE"])
result_file.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
print("Example module finished.")
