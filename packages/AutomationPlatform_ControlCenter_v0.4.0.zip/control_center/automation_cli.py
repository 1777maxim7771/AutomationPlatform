from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.catalog import CommandCatalog
from core.router import CommandRouter


def parse_value(raw: str):
    lowered = raw.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered == "null":
        return None
    try:
        return json.loads(raw)
    except Exception:
        return raw


def main():
    parser = argparse.ArgumentParser(prog="automation", description="AutomationPlatform command interface")
    sub = parser.add_subparsers(dest="action", required=True)

    sub.add_parser("list", help="List available commands")
    p_desc = sub.add_parser("describe", help="Describe one command")
    p_desc.add_argument("command")

    p_run = sub.add_parser("run", help="Run a command")
    p_run.add_argument("command")
    p_run.add_argument("--param", action="append", default=[], help="key=value; repeatable")
    p_run.add_argument("--json", dest="json_params", default=None, help="JSON object with parameters")

    args = parser.parse_args()
    catalog = CommandCatalog(ROOT)
    catalog.rebuild()

    if args.action == "list":
        print(json.dumps(catalog.read(), ensure_ascii=False, indent=2))
        return

    if args.action == "describe":
        cmd = catalog.command(args.command)
        if not cmd:
            print(json.dumps({"status": "failed", "error": "command_not_found"}, ensure_ascii=False))
            raise SystemExit(2)
        print(json.dumps(cmd, ensure_ascii=False, indent=2))
        return

    params = {}
    if args.json_params:
        params.update(json.loads(args.json_params))
    for item in args.param:
        if "=" not in item:
            raise SystemExit(f"Invalid --param: {item}")
        key, value = item.split("=", 1)
        params[key] = parse_value(value)

    result = CommandRouter(ROOT).execute(args.command, params)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result.get("status") not in ("success", "partial", "waiting", "needs_user", "needs_ai"):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
