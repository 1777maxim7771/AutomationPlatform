from __future__ import annotations

import json
import os
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.catalog import CommandCatalog
from core.router import CommandRouter
from core.secrets_store import SecretStore
from core.values_store import ValueStore
from core.module_installer import ModuleInstaller

APP_VERSION = "0.4.0"


class ControlCenter(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"AutomationPlatform Control Center v{APP_VERSION}")
        self.geometry("1220x790")
        self.minsize(1000, 660)

        self.bg = "#0f151d"
        self.panel = "#17212c"
        self.panel2 = "#202d3a"
        self.text = "#edf4fa"
        self.muted = "#96a9bd"
        self.accent = "#62d9ae"

        self.configure(bg=self.bg)
        self.catalog = CommandCatalog(ROOT)
        self.router = CommandRouter(ROOT)
        self.values = ValueStore(ROOT / "data" / "shared_values.json")
        self.secrets = SecretStore(ROOT / "data" / "secrets.dpapi.json")
        self.module_installer = ModuleInstaller(ROOT)
        self.param_widgets = {}

        self._styles()
        self._ui()
        self.refresh_all()

    def _styles(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure(".", background=self.bg, foreground=self.text)
        s.configure("TFrame", background=self.bg)
        s.configure("Panel.TFrame", background=self.panel)
        s.configure("TLabel", background=self.bg, foreground=self.text, font=("Segoe UI", 10))
        s.configure("Panel.TLabel", background=self.panel, foreground=self.text, font=("Segoe UI", 10))
        s.configure("Title.TLabel", background=self.bg, foreground=self.text, font=("Segoe UI Semibold", 19))
        s.configure("Sub.TLabel", background=self.bg, foreground=self.muted, font=("Segoe UI", 9))
        s.configure("TButton", background=self.panel2, foreground=self.text, padding=7)
        s.map("TButton", background=[("active", "#304154")])
        s.configure("Accent.TButton", background=self.accent, foreground="#07120e", padding=8, font=("Segoe UI Semibold", 10))
        s.map("Accent.TButton", background=[("active", "#7ae6c0")])
        s.configure("TEntry", fieldbackground=self.panel2, foreground=self.text, insertcolor=self.text)
        s.configure("TCombobox", fieldbackground=self.panel2, foreground=self.text)
        s.configure("Treeview", background=self.panel, fieldbackground=self.panel, foreground=self.text, rowheight=30)
        s.configure("Treeview.Heading", background=self.panel2, foreground=self.text, font=("Segoe UI Semibold", 9))
        s.map("Treeview", background=[("selected", "#285c4d")])
        s.configure("TNotebook", background=self.bg, borderwidth=0)
        s.configure("TNotebook.Tab", background=self.panel2, foreground=self.text, padding=(12, 8))
        s.map("TNotebook.Tab", background=[("selected", self.panel)])

    def _ui(self):
        top = ttk.Frame(self)
        top.pack(fill="x", padx=18, pady=(16, 8))
        ttk.Label(top, text="AutomationPlatform Control Center", style="Title.TLabel").pack(side="left")
        ttk.Label(top, text=f"Root: {ROOT}", style="Sub.TLabel").pack(side="left", padx=18, pady=(7, 0))
        ttk.Button(top, text="Пересканировать", command=self.refresh_all).pack(side="right")

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=18, pady=(0, 10))

        self.tab_dashboard = ttk.Frame(self.nb, style="Panel.TFrame")
        self.tab_commands = ttk.Frame(self.nb, style="Panel.TFrame")
        self.tab_values = ttk.Frame(self.nb, style="Panel.TFrame")
        self.tab_secrets = ttk.Frame(self.nb, style="Panel.TFrame")
        self.tab_modules = ttk.Frame(self.nb, style="Panel.TFrame")
        self.tab_logs = ttk.Frame(self.nb, style="Panel.TFrame")

        self.nb.add(self.tab_dashboard, text="Главная")
        self.nb.add(self.tab_commands, text="Команды")
        self.nb.add(self.tab_values, text="Параметры")
        self.nb.add(self.tab_secrets, text="Ключи / Secrets")
        self.nb.add(self.tab_modules, text="Модули")
        self.nb.add(self.tab_logs, text="Результаты")

        self._dashboard_ui()
        self._commands_ui()
        self._values_ui()
        self._secrets_ui()
        self._modules_ui()
        self._logs_ui()

        bottom = ttk.Frame(self)
        bottom.pack(fill="x", padx=18, pady=(0, 14))
        self.status_var = tk.StringVar(value="Готово")
        ttk.Label(bottom, textvariable=self.status_var, style="Sub.TLabel").pack(side="left")

    def _dashboard_ui(self):
        box = ttk.Frame(self.tab_dashboard, style="Panel.TFrame")
        box.pack(fill="x", padx=16, pady=16)
        ttk.Label(box, text="Первоначальный запуск / система", style="Panel.TLabel").pack(anchor="w", pady=(0, 9))
        self.health = tk.Text(box, height=10, bg=self.panel2, fg=self.text, relief="flat", font=("Consolas", 10), padx=10, pady=10)
        self.health.pack(fill="x")

        buttons = ttk.Frame(box, style="Panel.TFrame")
        buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(buttons, text="Проверить систему", command=self.dashboard_status).pack(side="left", padx=(0, 6))
        ttk.Button(buttons, text="Запустить Chrome Debug", style="Accent.TButton", command=lambda: self.run_quick("browser.start")).pack(side="left", padx=6)
        ttk.Button(buttons, text="Открыть Chrome Profile", command=self.open_profile).pack(side="left", padx=6)
        ttk.Button(buttons, text="Открыть D:\\AutomationPlatform", command=lambda: os.startfile(ROOT)).pack(side="left", padx=6)
        ttk.Button(buttons, text="Установка / обновление платформы", command=self.open_platform_installer).pack(side="left", padx=6)

        info = ttk.Frame(self.tab_dashboard, style="Panel.TFrame")
        info.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        ttk.Label(info, text="Единый интерфейс", style="Panel.TLabel").pack(anchor="w", pady=(0, 8))
        txt = (
            "Панель, automation_cli.py, AI-агент и будущие workflow используют один Command Router.\n\n"
            "AI не читает исходный код модулей. Ему достаточно commands\\catalog.json или команды:\n"
            "  automation_cli.py list\n"
            "  automation_cli.py describe <command>\n"
            "  automation_cli.py run <command> --param key=value\n\n"
            "Обычные значения: data\\shared_values.json\n"
            "Секреты: data\\secrets.dpapi.json (DPAPI, привязка к текущему пользователю Windows)."
        )
        label = ttk.Label(info, text=txt, style="Panel.TLabel", justify="left")
        label.pack(anchor="nw")

    def _commands_ui(self):
        left = ttk.Frame(self.tab_commands, style="Panel.TFrame")
        left.pack(side="left", fill="y", padx=(14, 7), pady=14)
        ttk.Label(left, text="Доступные команды", style="Panel.TLabel").pack(anchor="w", pady=(0, 6))
        self.command_list = tk.Listbox(left, width=40, bg=self.panel2, fg=self.text, selectbackground="#285c4d", relief="flat", font=("Consolas", 9))
        self.command_list.pack(fill="y", expand=True)
        self.command_list.bind("<<ListboxSelect>>", lambda e: self.show_command())

        right = ttk.Frame(self.tab_commands, style="Panel.TFrame")
        right.pack(side="left", fill="both", expand=True, padx=(7, 14), pady=14)
        self.command_title = ttk.Label(right, text="Выберите команду", style="Panel.TLabel")
        self.command_title.pack(anchor="w")
        self.command_desc = ttk.Label(right, text="", style="Panel.TLabel", wraplength=720, justify="left")
        self.command_desc.pack(anchor="w", pady=(3, 10))

        canvas = tk.Canvas(right, bg=self.panel, highlightthickness=0)
        scroll = ttk.Scrollbar(right, orient="vertical", command=canvas.yview)
        self.params_frame = ttk.Frame(canvas, style="Panel.TFrame")
        self.params_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.params_frame, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="left", fill="y")

        action = ttk.Frame(self.tab_commands, style="Panel.TFrame")
        action.place(relx=1.0, rely=1.0, anchor="se", x=-24, y=-20)
        ttk.Button(action, text="Выполнить команду", style="Accent.TButton", command=self.execute_selected).pack()

    def _values_ui(self):
        top = ttk.Frame(self.tab_values, style="Panel.TFrame")
        top.pack(fill="x", padx=14, pady=14)
        self.value_key = tk.StringVar()
        self.value_val = tk.StringVar()
        ttk.Label(top, text="Имя параметра", style="Panel.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(top, text="Значение (JSON или текст)", style="Panel.TLabel").grid(row=0, column=1, sticky="w")
        ttk.Entry(top, textvariable=self.value_key, width=34).grid(row=1, column=0, sticky="ew", padx=(0, 7), pady=(4, 0))
        ttk.Entry(top, textvariable=self.value_val).grid(row=1, column=1, sticky="ew", padx=7, pady=(4, 0))
        ttk.Button(top, text="Сохранить", style="Accent.TButton", command=self.save_value).grid(row=1, column=2, padx=(7, 0), pady=(4, 0))
        top.columnconfigure(1, weight=1)

        self.values_tree = ttk.Treeview(self.tab_values, columns=("key", "value"), show="headings")
        self.values_tree.heading("key", text="Параметр")
        self.values_tree.heading("value", text="Значение")
        self.values_tree.column("key", width=280)
        self.values_tree.column("value", width=700)
        self.values_tree.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        ttk.Button(self.tab_values, text="Удалить выбранный", command=self.delete_value).pack(anchor="e", padx=14, pady=(0, 14))

    def _secrets_ui(self):
        top = ttk.Frame(self.tab_secrets, style="Panel.TFrame")
        top.pack(fill="x", padx=14, pady=14)
        self.secret_name = tk.StringVar()
        self.secret_value = tk.StringVar()
        ttk.Label(top, text="Имя ключа", style="Panel.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(top, text="Секретное значение", style="Panel.TLabel").grid(row=0, column=1, sticky="w")
        ttk.Entry(top, textvariable=self.secret_name, width=34).grid(row=1, column=0, sticky="ew", padx=(0, 7), pady=(4, 0))
        ttk.Entry(top, textvariable=self.secret_value, show="●").grid(row=1, column=1, sticky="ew", padx=7, pady=(4, 0))
        ttk.Button(top, text="Зашифровать и сохранить", style="Accent.TButton", command=self.save_secret).grid(row=1, column=2, padx=(7, 0), pady=(4, 0))
        top.columnconfigure(1, weight=1)

        note = ttk.Label(
            self.tab_secrets,
            text="Значения не показываются в панели и не записываются в command catalog. "
                 "DPAPI привязывает их к текущему пользователю Windows.",
            style="Panel.TLabel",
            wraplength=1000,
            justify="left",
        )
        note.pack(anchor="w", padx=14, pady=(0, 8))

        self.secret_list = tk.Listbox(self.tab_secrets, bg=self.panel2, fg=self.text, relief="flat", font=("Consolas", 10))
        self.secret_list.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        ttk.Button(self.tab_secrets, text="Удалить выбранный ключ", command=self.delete_secret).pack(anchor="e", padx=14, pady=(0, 14))

    def _modules_ui(self):
        install = ttk.Frame(self.tab_modules, style="Panel.TFrame")
        install.pack(fill="x", padx=14, pady=(14, 4))
        ttk.Label(install, text="GitHub URL модуля", style="Panel.TLabel").pack(anchor="w")
        row = ttk.Frame(install, style="Panel.TFrame")
        row.pack(fill="x", pady=(4, 8))
        self.module_url = tk.StringVar()
        ttk.Entry(row, textvariable=self.module_url).pack(side="left", fill="x", expand=True, padx=(0, 8))
        ttk.Button(row, text="Скачать / установить", style="Accent.TButton", command=self.install_github_module).pack(side="right")

        self.modules_tree = ttk.Treeview(self.tab_modules, columns=("id", "name", "version", "source", "path"), show="headings")
        for c, title, width in [
            ("id", "ID", 180),
            ("name", "Название", 220),
            ("version", "Версия", 90),
            ("source", "Источник", 310),
            ("path", "Путь", 430),
        ]:
            self.modules_tree.heading(c, text=title)
            self.modules_tree.column(c, width=width)
        self.modules_tree.pack(fill="both", expand=True, padx=14, pady=8)

        bar = ttk.Frame(self.tab_modules, style="Panel.TFrame")
        bar.pack(fill="x", padx=14, pady=(0, 14))
        ttk.Button(bar, text="Пересканировать module.json", command=self.refresh_all).pack(side="left")
        ttk.Button(bar, text="Обновить выбранный из GitHub", command=self.update_github_module).pack(side="left", padx=8)
        ttk.Button(bar, text="Открыть папку modules", command=lambda: os.startfile(ROOT / "modules")).pack(side="left", padx=8)

    def install_github_module(self):
        url = self.module_url.get().strip()
        if not url:
            messagebox.showwarning("Модуль", "Введите GitHub URL.")
            return
        self.status_var.set("Скачиваю модуль из GitHub…")
        threading.Thread(target=self._install_module_worker, args=(url,), daemon=True).start()

    def _install_module_worker(self, url):
        try:
            result = self.module_installer.install(url)
            self.catalog.rebuild()
            self.after(0, self.refresh_all)
            self.after(0, lambda: self.status_var.set(
                f"Установлен модуль: {result.get('name')} v{result.get('version')}"
            ))
            self.after(0, lambda: messagebox.showinfo(
                "Модуль установлен",
                json.dumps(result, ensure_ascii=False, indent=2)
            ))
        except Exception as exc:
            self.after(0, lambda: self.status_var.set(f"Ошибка установки модуля: {exc}"))
            self.after(0, lambda: messagebox.showerror("Установка модуля", str(exc)))

    def update_github_module(self):
        sel = self.modules_tree.selection()
        if not sel:
            messagebox.showwarning("Модуль", "Выберите модуль.")
            return
        module_id = sel[0]
        self.status_var.set(f"Обновляю модуль {module_id}…")
        threading.Thread(target=self._update_module_worker, args=(module_id,), daemon=True).start()

    def _update_module_worker(self, module_id):
        try:
            result = self.module_installer.update(module_id)
            self.catalog.rebuild()
            self.after(0, self.refresh_all)
            self.after(0, lambda: self.status_var.set(
                f"Обновлён модуль: {result.get('name')} v{result.get('version')}"
            ))
        except Exception as exc:
            self.after(0, lambda: self.status_var.set(f"Ошибка обновления: {exc}"))
            self.after(0, lambda: messagebox.showerror("Обновление модуля", str(exc)))

    def _logs_ui(self):
        left = ttk.Frame(self.tab_logs, style="Panel.TFrame")
        left.pack(side="left", fill="y", padx=(14, 7), pady=14)
        self.results_list = tk.Listbox(left, width=42, bg=self.panel2, fg=self.text, relief="flat", font=("Consolas", 9))
        self.results_list.pack(fill="y", expand=True)
        self.results_list.bind("<<ListboxSelect>>", lambda e: self.show_result())

        right = ttk.Frame(self.tab_logs, style="Panel.TFrame")
        right.pack(side="left", fill="both", expand=True, padx=(7, 14), pady=14)
        self.result_text = tk.Text(right, bg=self.panel2, fg=self.text, relief="flat", font=("Consolas", 9), padx=10, pady=10)
        self.result_text.pack(fill="both", expand=True)

    def refresh_all(self):
        data = self.catalog.rebuild()
        self.command_list.delete(0, "end")
        for cmd in data.get("commands", []):
            self.command_list.insert("end", cmd["id"])

        self.modules_tree.delete(*self.modules_tree.get_children())
        for mid, rec in sorted(data.get("modules", {}).items()):
            source = rec.get("source", {})
            source_text = source.get("url", "") if isinstance(source, dict) else ""
            self.modules_tree.insert("", "end", iid=mid, values=(mid, rec.get("name", mid), rec.get("version", ""), source_text, rec.get("path", "")))

        self.refresh_values()
        self.refresh_secrets()
        self.refresh_results()
        self.dashboard_status()
        self.status_var.set(f"Каталог обновлён • команд: {len(data.get('commands', []))}")

    def selected_command_id(self):
        sel = self.command_list.curselection()
        return self.command_list.get(sel[0]) if sel else None

    def show_command(self):
        for child in self.params_frame.winfo_children():
            child.destroy()
        self.param_widgets = {}

        cid = self.selected_command_id()
        if not cid:
            return
        cmd = self.catalog.command(cid)
        self.command_title.configure(text=f"{cmd.get('name', cid)}  [{cid}]")
        self.command_desc.configure(text=cmd.get("description", ""))

        row = 0
        for name, spec in (cmd.get("parameters") or {}).items():
            if not isinstance(spec, dict):
                spec = {"type": "string"}
            required = " *" if spec.get("required") else ""
            ttk.Label(self.params_frame, text=f"{name}{required}", style="Panel.TLabel").grid(row=row, column=0, sticky="w", padx=(0, 12), pady=(7, 2))
            ttk.Label(self.params_frame, text=spec.get("description", ""), style="Panel.TLabel", wraplength=520, justify="left").grid(row=row, column=1, sticky="w", pady=(7, 2))
            row += 1

            ptype = spec.get("type", "string")
            default = spec.get("default", "")
            if spec.get("default_from"):
                default = self.values.get(str(spec["default_from"]), default)

            if ptype == "boolean":
                var = tk.BooleanVar(value=bool(default))
                widget = ttk.Checkbutton(self.params_frame, variable=var)
            elif ptype == "choice":
                var = tk.StringVar(value=str(default or ""))
                widget = ttk.Combobox(self.params_frame, textvariable=var, values=spec.get("choices", []), state="readonly")
            elif ptype == "secret_ref":
                var = tk.StringVar(value=str(default or ""))
                widget = ttk.Combobox(self.params_frame, textvariable=var, values=self.secrets.names(), state="readonly")
            else:
                var = tk.StringVar(value="" if default is None else str(default))
                widget = ttk.Entry(self.params_frame, textvariable=var, width=72)

            widget.grid(row=row, column=0, columnspan=2, sticky="ew", pady=(0, 6))
            self.params_frame.columnconfigure(1, weight=1)
            self.param_widgets[name] = (var, spec)
            row += 1

    def execute_selected(self):
        cid = self.selected_command_id()
        if not cid:
            messagebox.showwarning("Команда", "Выберите команду.")
            return
        params = {name: var.get() for name, (var, spec) in self.param_widgets.items()}
        self.status_var.set(f"Выполняется: {cid}")
        threading.Thread(target=self._execute_worker, args=(cid, params), daemon=True).start()

    def _execute_worker(self, cid, params):
        try:
            result = self.router.execute(cid, params)
            self.after(0, lambda: self.status_var.set(f"{cid}: {result.get('status')} • {result.get('summary', '')}"))
            self.after(0, self.refresh_results)
            self.after(0, self.dashboard_status)
            self.after(0, lambda: messagebox.showinfo("Результат", json.dumps(result, ensure_ascii=False, indent=2)[:3500]))
        except Exception as exc:
            self.after(0, lambda: self.status_var.set(f"Ошибка: {exc}"))
            self.after(0, lambda: messagebox.showerror("Ошибка команды", str(exc)))

    def run_quick(self, cid):
        self.status_var.set(f"Выполняется: {cid}")
        threading.Thread(target=self._execute_worker, args=(cid, {}), daemon=True).start()

    def dashboard_status(self):
        try:
            result = self.router.execute("system.status", {})
            self.health.configure(state="normal")
            self.health.delete("1.0", "end")
            self.health.insert("1.0", json.dumps(result.get("data", {}), ensure_ascii=False, indent=2))
            self.health.configure(state="disabled")
        except Exception as exc:
            self.health.configure(state="normal")
            self.health.delete("1.0", "end")
            self.health.insert("1.0", str(exc))
            self.health.configure(state="disabled")

    def open_platform_installer(self):
        candidates = [
            ROOT / "installer" / "START_PLATFORM_INSTALLER.ps1",
            ROOT / "START_PLATFORM_INSTALLER.ps1",
        ]
        script = next((p for p in candidates if p.exists()), None)
        if not script:
            messagebox.showwarning(
                "Installer",
                "START_PLATFORM_INSTALLER.ps1 не найден.\n"
                "Скопируйте его из главного GitHub Repository в D:\\AutomationPlatform\\installer."
            )
            return
        os.spawnv(
            os.P_NOWAIT,
            r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)]
        )

    def open_profile(self):
        cfg_path = ROOT / "config" / "platform.json"
        if cfg_path.exists():
            cfg = json.loads(cfg_path.read_text(encoding="utf-8-sig"))
            p = Path(cfg.get("chrome_profile", ROOT / "browser" / "Chrome_Profile"))
        else:
            p = ROOT / "browser" / "Chrome_Profile"
        p.mkdir(parents=True, exist_ok=True)
        os.startfile(p)

    def refresh_values(self):
        self.values_tree.delete(*self.values_tree.get_children())
        for key, val in sorted(self.values.read()["values"].items()):
            self.values_tree.insert("", "end", iid=key, values=(key, json.dumps(val, ensure_ascii=False) if not isinstance(val, str) else val))

    def save_value(self):
        key = self.value_key.get().strip()
        raw = self.value_val.get()
        if not key:
            return
        try:
            value = json.loads(raw)
        except Exception:
            value = raw
        self.values.set(key, value)
        self.value_key.set("")
        self.value_val.set("")
        self.refresh_values()

    def delete_value(self):
        sel = self.values_tree.selection()
        if not sel:
            return
        self.values.delete(sel[0])
        self.refresh_values()

    def refresh_secrets(self):
        self.secret_list.delete(0, "end")
        for name in self.secrets.names():
            self.secret_list.insert("end", name)

    def save_secret(self):
        name = self.secret_name.get().strip()
        value = self.secret_value.get()
        if not name or not value:
            messagebox.showwarning("Secret", "Введите имя и значение.")
            return
        try:
            self.secrets.set(name, value)
        except Exception as exc:
            messagebox.showerror("Secret", str(exc))
            return
        self.secret_name.set("")
        self.secret_value.set("")
        self.refresh_secrets()
        self.show_command()
        self.status_var.set(f"Secret сохранён: {name}")

    def delete_secret(self):
        sel = self.secret_list.curselection()
        if not sel:
            return
        name = self.secret_list.get(sel[0])
        if messagebox.askyesno("Secret", f"Удалить {name}?"):
            self.secrets.delete(name)
            self.refresh_secrets()
            self.show_command()

    def refresh_results(self):
        self.results_list.delete(0, "end")
        result_dir = ROOT / "jobs" / "results"
        result_dir.mkdir(parents=True, exist_ok=True)
        files = sorted(result_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        for p in files[:300]:
            self.results_list.insert("end", p.name)

    def show_result(self):
        sel = self.results_list.curselection()
        if not sel:
            return
        p = ROOT / "jobs" / "results" / self.results_list.get(sel[0])
        self.result_text.delete("1.0", "end")
        try:
            self.result_text.insert("1.0", p.read_text(encoding="utf-8"))
        except Exception as exc:
            self.result_text.insert("1.0", str(exc))


if __name__ == "__main__":
    ControlCenter().mainloop()
