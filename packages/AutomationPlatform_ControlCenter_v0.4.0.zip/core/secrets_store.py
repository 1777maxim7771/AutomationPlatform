from __future__ import annotations

import base64
import ctypes
import json
import os
from ctypes import wintypes
from pathlib import Path

CRYPTPROTECT_UI_FORBIDDEN = 0x1


class DATA_BLOB(ctypes.Structure):
    _fields_ = [
        ("cbData", wintypes.DWORD),
        ("pbData", ctypes.POINTER(ctypes.c_byte)),
    ]


def _blob(data: bytes):
    buf = ctypes.create_string_buffer(data)
    return DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte))), buf


def _protect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("DPAPI secret storage is available only on Windows.")
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    in_blob, in_buf = _blob(data)
    out_blob = DATA_BLOB()
    ok = crypt32.CryptProtectData(
        ctypes.byref(in_blob),
        "AutomationPlatform",
        None,
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(out_blob),
    )
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


def _unprotect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("DPAPI secret storage is available only on Windows.")
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    in_blob, in_buf = _blob(data)
    out_blob = DATA_BLOB()
    ok = crypt32.CryptUnprotectData(
        ctypes.byref(in_blob),
        None,
        None,
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(out_blob),
    )
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


class SecretStore:
    """Windows-user-bound DPAPI encrypted secret store."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _read_raw(self) -> dict:
        if not self.path.exists():
            return {"schema_version": 1, "secrets": {}}
        with self.path.open("r", encoding="utf-8") as f:
            obj = json.load(f)
        obj.setdefault("schema_version", 1)
        obj.setdefault("secrets", {})
        return obj

    def _write_raw(self, obj: dict) -> None:
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        with temp.open("w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, self.path)

    def names(self) -> list[str]:
        return sorted(self._read_raw().get("secrets", {}).keys())

    def set(self, name: str, value: str) -> None:
        name = name.strip()
        if not name:
            raise ValueError("Secret name is empty.")
        enc = _protect(value.encode("utf-8"))
        obj = self._read_raw()
        obj["secrets"][name] = base64.b64encode(enc).decode("ascii")
        self._write_raw(obj)

    def get(self, name: str) -> str:
        obj = self._read_raw()
        encoded = obj.get("secrets", {}).get(name)
        if encoded is None:
            raise KeyError(name)
        raw = base64.b64decode(encoded)
        return _unprotect(raw).decode("utf-8")

    def delete(self, name: str) -> None:
        obj = self._read_raw()
        obj.get("secrets", {}).pop(name, None)
        self._write_raw(obj)
