from __future__ import annotations

import json
import re
import shutil
import tempfile
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path


def _json(url: str) -> dict:
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "AutomationPlatform-ControlCenter/0.4",
            "Accept": "application/vnd.github+json",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


def _download(url: str, path: Path):
    req = urllib.request.Request(url, headers={"User-Agent": "AutomationPlatform-ControlCenter/0.4"})
    with urllib.request.urlopen(req, timeout=90) as r, path.open("wb") as f:
        shutil.copyfileobj(r, f)


def _parse_repo(url: str):
    p = urllib.parse.urlparse(url.strip())
    if p.scheme not in ("http", "https") or p.netloc.lower() not in ("github.com", "www.github.com"):
        raise ValueError("Нужна ссылка вида https://github.com/OWNER/REPOSITORY")
    parts = [x for x in p.path.split("/") if x]
    if len(parts) < 2:
        raise ValueError("В GitHub URL отсутствует OWNER/REPOSITORY.")
    owner = parts[0]
    repo = parts[1].removesuffix(".git")
    branch = parts[3] if len(parts) >= 4 and parts[2] == "tree" else None
    return owner, repo, branch


def _single_root(path: Path):
    children = [p for p in path.iterdir() if p.name != "__MACOSX"]
    dirs = [p for p in children if p.is_dir()]
    files = [p for p in children if p.is_file()]
    return dirs[0] if len(dirs) == 1 and not files else path


def _safe_id(value: str):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip()).strip("._-") or "module"


class ModuleInstaller:
    def __init__(self, root: Path):
        self.root = root
        self.modules_dir = root / "modules"
        self.backups_dir = root / "_update" / "module_backups"
        self.modules_dir.mkdir(parents=True, exist_ok=True)
        self.backups_dir.mkdir(parents=True, exist_ok=True)

    def install(self, repo_url: str) -> dict:
        owner, repo, branch = _parse_repo(repo_url)
        if not branch:
            info = _json(f"https://api.github.com/repos/{owner}/{repo}")
            branch = info.get("default_branch") or "main"

        encoded = urllib.parse.quote(branch, safe="")
        archive_url = f"https://codeload.github.com/{owner}/{repo}/zip/refs/heads/{encoded}"

        temp = Path(tempfile.mkdtemp(prefix="automation_module_"))
        try:
            archive = temp / "module.zip"
            _download(archive_url, archive)
            extract = temp / "extract"
            extract.mkdir()
            with zipfile.ZipFile(archive, "r") as z:
                z.extractall(extract)
            source = _single_root(extract)

            mf = source / "module.json"
            if not mf.exists():
                raise RuntimeError("В корне GitHub-модуля отсутствует module.json.")

            manifest = json.loads(mf.read_text(encoding="utf-8"))
            module_id = _safe_id(str(manifest.get("id") or repo))
            manifest["id"] = module_id
            manifest.setdefault("name", module_id)
            manifest.setdefault("version", "0.0.0")
            manifest.setdefault("platform_api", 1)
            manifest.setdefault("commands", [])
            manifest["source"] = {
                "type": "github",
                "url": repo_url,
                "owner": owner,
                "repo": repo,
                "branch": branch,
            }

            dest = self.modules_dir / module_id
            backup = None
            if dest.exists():
                backup = self.backups_dir / f"{module_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                shutil.move(str(dest), str(backup))

            try:
                shutil.copytree(source, dest)
                (dest / "module.json").write_text(
                    json.dumps(manifest, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            except Exception:
                shutil.rmtree(dest, ignore_errors=True)
                if backup and backup.exists():
                    shutil.move(str(backup), str(dest))
                raise

            return {
                "status": "success",
                "id": module_id,
                "name": manifest["name"],
                "version": manifest["version"],
                "path": str(dest),
                "source": manifest["source"],
                "backup": str(backup) if backup else None,
            }
        finally:
            shutil.rmtree(temp, ignore_errors=True)

    def update(self, module_id: str) -> dict:
        mf = self.modules_dir / module_id / "module.json"
        if not mf.exists():
            raise FileNotFoundError(mf)
        manifest = json.loads(mf.read_text(encoding="utf-8"))
        url = manifest.get("source", {}).get("url")
        if not url:
            raise RuntimeError("У модуля нет source.url. Обновление из GitHub невозможно.")
        return self.install(url)
