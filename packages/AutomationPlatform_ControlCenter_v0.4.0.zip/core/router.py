from __future__ import annotations

import json
import os
import subprocess
import sys
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

from core.catalog import CommandCatalog
from core.secrets_store import SecretStore
from core.values_store import ValueStore


def utc_now():
    return datetime.now(timezone.utc).isoformat()


class CommandRouter:
    def __init__(self, root: Path):
        self.root = root
        self.catalog = CommandCatalog(root)
        self.values = ValueStore(root / "data" / "shared_values.json")
        self.secrets = SecretStore(root / "data" / "secrets.dpapi.json")
        self.jobs_running = root / "jobs" / "running"
        self.jobs_results = root / "jobs" / "results"
        self.logs = root / "logs"
        for p in (self.jobs_running, self.jobs_results, self.logs):
            p.mkdir(parents=True, exist_ok=True)

    def _platform_config(self) -> dict:
        p = self.root / "config" / "platform.json"
        if not p.exists():
            return {}
        with p.open("r", encoding="utf-8-sig") as f:
            return json.load(f)

    def _resolve_params(self, command: dict, supplied: dict) -> tuple[dict, dict]:
        schema = command.get("parameters", {}) or {}
        public_params = {}
        resolved_params = {}

        for name, spec in schema.items():
            if not isinstance(spec, dict):
                spec = {"type": "string"}
            ptype = spec.get("type", "string")
            required = bool(spec.get("required", False))

            if name in supplied:
                value = supplied[name]
            elif spec.get("default_from"):
                value = self.values.get(str(spec["default_from"]))
            elif "default" in spec:
                value = spec.get("default")
            else:
                value = None

            if ptype == "secret_ref":
                if value in (None, ""):
                    if required:
                        raise ValueError(f"Required secret reference missing: {name}")
                    public_params[name] = None
                    resolved_params[name] = None
                else:
                    secret_name = str(value)
                    public_params[name] = {"secret_ref": secret_name}
                    resolved_params[name] = self.secrets.get(secret_name)
                continue

            if value in (None, "") and required:
                raise ValueError(f"Required parameter missing: {name}")

            if ptype in ("integer", "int") and value not in (None, ""):
                value = int(value)
            elif ptype in ("number", "float") and value not in (None, ""):
                value = float(value)
            elif ptype == "boolean":
                if isinstance(value, str):
                    value = value.strip().lower() in ("1", "true", "yes", "on", "да")
                else:
                    value = bool(value)

            public_params[name] = value
            resolved_params[name] = value

        # Preserve explicitly supplied extra parameters too.
        for name, value in supplied.items():
            if name not in schema:
                public_params[name] = value
                resolved_params[name] = value

        return public_params, resolved_params

    def execute(self, command_id: str, params: dict | None = None) -> dict:
        params = params or {}
        command = self.catalog.command(command_id)
        if not command:
            raise KeyError(f"Unknown command: {command_id}")

        public_params, resolved_params = self._resolve_params(command, params)

        run_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        job_public = {
            "run_id": run_id,
            "command_id": command_id,
            "module_id": command.get("module_id"),
            "params": public_params,
            "created_at": utc_now(),
        }
        running_file = self.jobs_running / f"{run_id}.json"
        running_file.write_text(json.dumps(job_public, ensure_ascii=False, indent=2), encoding="utf-8")

        if command.get("module_id") == "__core__":
            result = self._execute_builtin(command_id, resolved_params)
            result.setdefault("run_id", run_id)
            result.setdefault("command_id", command_id)
            result.setdefault("finished_at", utc_now())
            result_file = self.jobs_results / f"{run_id}.json"
            result_file.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            running_file.unlink(missing_ok=True)
            return result

        result = self._execute_module(run_id, command, job_public, resolved_params)
        running_file.unlink(missing_ok=True)
        return result

    def _execute_builtin(self, command_id: str, params: dict) -> dict:
        cfg = self._platform_config()

        if command_id == "modules.rescan":
            data = self.catalog.rebuild()
            return {
                "status": "success",
                "summary": f"Catalog rebuilt. Commands: {len(data.get('commands', []))}",
            }

        if command_id == "system.status":
            py = self.root / "runtime" / "python" / "python.exe"
            chrome = Path(cfg.get("chrome_exe", "")) if cfg.get("chrome_exe") else None
            profile = Path(cfg.get("chrome_profile", str(self.root / "browser" / "Chrome_Profile")))
            cdp = self._cdp_status(cfg)
            return {
                "status": "success",
                "summary": "Platform status collected.",
                "data": {
                    "root": str(self.root),
                    "python": {"path": str(py), "exists": py.exists()},
                    "chrome": {"path": str(chrome) if chrome else "", "exists": bool(chrome and chrome.exists())},
                    "profile": {"path": str(profile), "exists": profile.exists()},
                    "cdp": cdp,
                },
            }

        if command_id == "browser.status":
            return {
                "status": "success",
                "summary": "CDP status collected.",
                "data": self._cdp_status(cfg),
            }

        if command_id == "browser.start":
            chrome = Path(cfg.get("chrome_exe", ""))
            profile = Path(cfg.get("chrome_profile", str(self.root / "browser" / "Chrome_Profile")))
            port = int(cfg.get("debug_port", 9222))
            if not chrome.exists():
                return {
                    "status": "failed",
                    "summary": "Chrome executable not found.",
                    "error": {"code": "CHROME_NOT_FOUND", "path": str(chrome)},
                }
            profile.mkdir(parents=True, exist_ok=True)
            url = str(params.get("url") or "https://chatgpt.com/")
            subprocess.Popen([
                str(chrome),
                f"--remote-debugging-port={port}",
                "--remote-debugging-address=127.0.0.1",
                "--remote-allow-origins=*",
                f"--user-data-dir={profile}",
                url,
            ])
            return {
                "status": "success",
                "summary": f"Chrome Debug started on port {port}.",
                "data": {"profile": str(profile), "url": url, "port": port},
            }

        return {"status": "failed", "summary": f"Built-in command not implemented: {command_id}"}

    def _cdp_status(self, cfg: dict) -> dict:
        host = str(cfg.get("cdp_host", "127.0.0.1"))
        port = int(cfg.get("debug_port", 9222))
        url = f"http://{host}:{port}/json/version"
        try:
            with urllib.request.urlopen(url, timeout=1.2) as r:
                data = json.loads(r.read().decode("utf-8"))
            return {
                "connected": True,
                "host": host,
                "port": port,
                "browser": data.get("Browser"),
                "websocket": data.get("webSocketDebuggerUrl"),
            }
        except Exception as exc:
            return {"connected": False, "host": host, "port": port, "error": str(exc)}

    def _execute_module(self, run_id: str, command: dict, public_job: dict, resolved_params: dict) -> dict:
        module_path = Path(command.get("module_path", ""))
        entry = command.get("entrypoint")
        if not entry:
            raise RuntimeError(f"Module {command.get('module_id')} has no entrypoint.")
        entry_path = module_path / str(entry)
        if not entry_path.exists():
            raise FileNotFoundError(entry_path)

        secure_job_file = self.jobs_running / f"{run_id}.secure.json"
        result_file = self.jobs_results / f"{run_id}.json"
        log_file = self.logs / f"{run_id}_{command.get('module_id')}.log"

        secure_job = dict(public_job)
        secure_job["params"] = resolved_params
        secure_job["result_file"] = str(result_file)
        secure_job["log_file"] = str(log_file)
        secure_job_file.write_text(json.dumps(secure_job, ensure_ascii=False, indent=2), encoding="utf-8")

        env = os.environ.copy()
        env.update({
            "AUTOMATION_ROOT": str(self.root),
            "AUTOMATION_RUN_ID": run_id,
            "AUTOMATION_COMMAND_ID": str(command["id"]),
            "AUTOMATION_JOB_FILE": str(secure_job_file),
            "AUTOMATION_RESULT_FILE": str(result_file),
            "AUTOMATION_MODULE_ID": str(command.get("module_id")),
        })

        python_exe = self.root / "runtime" / "python" / "python.exe"
        if not python_exe.exists():
            python_exe = Path(sys.executable)

        with log_file.open("w", encoding="utf-8") as log:
            proc = subprocess.run(
                [str(python_exe), str(entry_path), "--automation-job", str(secure_job_file)],
                cwd=str(module_path),
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
            )

        # Secure job may contain resolved secrets; delete immediately after process exits.
        secure_job_file.unlink(missing_ok=True)

        if result_file.exists():
            try:
                result = json.loads(result_file.read_text(encoding="utf-8"))
            except Exception:
                result = {}
        else:
            result = {}

        result.setdefault("run_id", run_id)
        result.setdefault("command_id", command["id"])
        result.setdefault("status", "success" if proc.returncode == 0 else "failed")
        result.setdefault("summary", f"Module finished with code {proc.returncode}.")
        result.setdefault("returncode", proc.returncode)
        result.setdefault("log_file", str(log_file))
        result.setdefault("finished_at", utc_now())
        result_file.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return result
