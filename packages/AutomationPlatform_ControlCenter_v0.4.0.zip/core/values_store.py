from __future__ import annotations

import json
import os
from pathlib import Path


class ValueStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def read(self) -> dict:
        if not self.path.exists():
            return {"schema_version": 1, "values": {}}
        with self.path.open("r", encoding="utf-8") as f:
            obj = json.load(f)
        obj.setdefault("schema_version", 1)
        obj.setdefault("values", {})
        return obj

    def write(self, obj: dict) -> None:
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        with temp.open("w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, self.path)

    def names(self) -> list[str]:
        return sorted(self.read()["values"].keys())

    def get(self, key: str, default=None):
        return self.read()["values"].get(key, default)

    def set(self, key: str, value):
        key = key.strip()
        if not key:
            raise ValueError("Key is empty.")
        obj = self.read()
        obj["values"][key] = value
        self.write(obj)

    def delete(self, key: str):
        obj = self.read()
        obj["values"].pop(key, None)
        self.write(obj)
