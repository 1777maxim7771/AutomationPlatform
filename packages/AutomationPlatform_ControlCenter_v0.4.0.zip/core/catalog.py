from __future__ import annotations

import json
from pathlib import Path


BUILTIN_COMMANDS = [
    {
        "id": "system.status",
        "name": "Состояние платформы",
        "description": "Проверяет локальный Python, Chrome, Chrome Profile и CDP.",
        "module_id": "__core__",
        "parameters": {}
    },
    {
        "id": "browser.start",
        "name": "Запустить Chrome Debug",
        "description": "Запускает Automation Chrome с отдельным профилем и CDP.",
        "module_id": "__core__",
        "parameters": {
            "url": {
                "type": "url",
                "required": False,
                "default": "https://chatgpt.com/",
                "description": "Стартовая страница."
            }
        }
    },
    {
        "id": "browser.status",
        "name": "Проверить Chrome Debug",
        "description": "Проверяет доступность CDP endpoint.",
        "module_id": "__core__",
        "parameters": {}
    },
    {
        "id": "modules.rescan",
        "name": "Пересканировать модули",
        "description": "Перечитывает module.json всех локальных модулей и обновляет catalog.json.",
        "module_id": "__core__",
        "parameters": {}
    }
]


class CommandCatalog:
    def __init__(self, root: Path):
        self.root = root
        self.modules_dir = root / "modules"
        self.catalog_file = root / "commands" / "catalog.json"

    def rebuild(self) -> dict:
        commands = [dict(x) for x in BUILTIN_COMMANDS]
        modules = {}

        self.modules_dir.mkdir(parents=True, exist_ok=True)
        for module_dir in sorted(self.modules_dir.iterdir()):
            if not module_dir.is_dir():
                continue
            mf = module_dir / "module.json"
            if not mf.exists():
                continue
            try:
                manifest = json.loads(mf.read_text(encoding="utf-8"))
            except Exception as exc:
                modules[module_dir.name] = {
                    "status": "invalid_manifest",
                    "error": str(exc),
                    "path": str(module_dir),
                }
                continue

            module_id = str(manifest.get("id") or module_dir.name)
            modules[module_id] = {
                "name": manifest.get("name", module_id),
                "version": str(manifest.get("version", "0.0.0")),
                "platform_api": int(manifest.get("platform_api", 1)),
                "entrypoint": manifest.get("entrypoint"),
                "path": str(module_dir),
                "source": manifest.get("source", {}),
                "requires": manifest.get("requires", []),
                "status": "installed",
            }

            for cmd in manifest.get("commands", []):
                if not isinstance(cmd, dict) or not cmd.get("id"):
                    continue
                item = dict(cmd)
                item.setdefault("name", item["id"])
                item.setdefault("description", "")
                item.setdefault("parameters", {})
                item["module_id"] = module_id
                item["module_path"] = str(module_dir)
                item["entrypoint"] = manifest.get("entrypoint")
                commands.append(item)

        out = {
            "schema_version": 1,
            "platform_api": 1,
            "commands": sorted(commands, key=lambda x: x["id"]),
            "modules": modules,
        }
        self.catalog_file.parent.mkdir(parents=True, exist_ok=True)
        self.catalog_file.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        return out

    def read(self) -> dict:
        if not self.catalog_file.exists():
            return self.rebuild()
        try:
            return json.loads(self.catalog_file.read_text(encoding="utf-8"))
        except Exception:
            return self.rebuild()

    def command(self, command_id: str) -> dict | None:
        for cmd in self.read().get("commands", []):
            if cmd.get("id") == command_id:
                return cmd
        return None
