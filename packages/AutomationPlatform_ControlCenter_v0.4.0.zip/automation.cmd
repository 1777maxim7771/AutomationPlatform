@echo off
setlocal
cd /d "%~dp0"
set "PY=%~dp0runtime\python\python.exe"
if not exist "%PY%" (
  where py >nul 2>nul && py -3 "%~dp0control_center\automation_cli.py" %* & exit /b %errorlevel%
  where python >nul 2>nul && python "%~dp0control_center\automation_cli.py" %* & exit /b %errorlevel%
  echo [ERROR] Python runtime not found.
  exit /b 1
)
"%PY%" "%~dp0control_center\automation_cli.py" %*
exit /b %errorlevel%
