@echo off
setlocal
cd /d "%~dp0"

set "PYW=%~dp0runtime\python\pythonw.exe"
if exist "%PYW%" (
  start "" "%PYW%" "%~dp0control_center\gui.py"
  exit /b 0
)

where py >nul 2>nul
if not errorlevel 1 (
  start "" pyw -3 "%~dp0control_center\gui.py"
  exit /b 0
)

where pythonw >nul 2>nul
if not errorlevel 1 (
  start "" pythonw "%~dp0control_center\gui.py"
  exit /b 0
)

echo [ERROR] Python runtime not found.
echo Run the AutomationPlatform Bootstrap first.
pause
